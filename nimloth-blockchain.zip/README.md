# Nimloth Blockchain

Exposed on `localhost:8000`

`docker compose up` to start containers<br/>
`docker compose stop` to stop containers<br/>
`docker compose down` to stop and remove containers<br/>
`docker compose build` to rebuild the image<br/>

`pipenv install`<br/>
`pipenv install --dev`<br/>
`pre-commit install` to install pre-commit hooks<br/>
